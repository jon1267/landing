Note:
====

Responsive, Bootstrap Mobile First Web Template 
Author URI: http://webthemez.com/


Eden Real estate template � is a real estate builders theme especially for industry that need modern and elegant looks. This template is developed on HTML5, Bootstrap 3.3.1 and fully Responsive site. This template suitable for Real estate, Builders, Constructions, Architecture sites. This theme is easy to customize as per you requirements.


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
http://kiviart.com/picturesque-rooftop-garden-ideas/magnificent-rooftop-garden-decorations-design-ideas-with-fascinating-outdoor-purple-patio-chair-and-long-dining-set-with-sophisticated-skyscraper-architecture-building-city-scape/
http://www.track2realty.com/


Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)


Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	